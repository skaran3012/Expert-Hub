//
//  AppDelegate.h
//  ProjectTesting
//
//  Created by Mehul Panchal on 01/03/16.
//  Copyright (c) 2016 Vnurture Technology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

