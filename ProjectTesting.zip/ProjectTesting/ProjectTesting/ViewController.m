//
//  ViewController.m
//  ProjectTesting
//
//  Created by Mehul Panchal on 01/03/16.
//  Copyright (c) 2016 Vnurture Technology. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //CGFloat navigationBarHeight = self.topLayoutGuide.length;

    
    //self.imgBackround=[UIImageView alloc]initWithImage:[uiimage]
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
